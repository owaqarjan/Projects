.. include:: ../README.rst

.. toctree::
   :hidden:

   tutorial
   reference
