Python Pattern Matching Tutorial
================================

.. todo::

   Demonstrate what's possible!

   - https://xmonader.github.io/prolog/2018/12/21/solving-murder-prolog.html
   - Optimizer for expressions with namedtuples.
